﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data.Models
{
    public enum Initial
    {
        JUV = 10,
        LIV = 20,
        ARS = 30
    }
}
